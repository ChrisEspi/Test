
public class One {

	public static void main(String[] args) {
		int open = 0;
		int close = 0;
		
		for (open = 700; open < 230; open+=30) {
			if(){
				
			}
		}

	}

}
